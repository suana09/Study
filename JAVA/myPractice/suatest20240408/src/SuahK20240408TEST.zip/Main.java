package testProject;

public class Main {

    //메인메뉴 실행
    public static void main(String[] args) {
        Menu mainmenu = new Menu();
        mainmenu.mainMenu();
    }

}
